
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class GeminiService {

    private static final String MODEL = "gemini-3.5-flash-lite";

    private static final String API_URL =
        "https://generativelanguage.googleapis.com/v1beta/models/"
        + MODEL + ":generateContent";

    private final HttpClient client = HttpClient.newBuilder()
        .connectTimeout(Duration.ofSeconds(20))
        .build();

    public String askAI(String message) throws Exception {

        String apiKey = System.getenv("GEMINI_API_KEY");

        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException(
                "Gemini API key is not configured."
            );
        }

        String prompt =
            "You are SmartBite AI, a helpful food ordering assistant. "
            + "Our menu is Burger Rs.120, Pizza Rs.250, "
            + "Biryani Rs.180 and Sandwich Rs.90. "
            + "Answer the customer's question: " + message;

        String escapedPrompt = prompt
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n");

        String json = """
            {
              "contents": [{
                "parts": [{
                  "text": "%s"
                }]
              }]
            }
            """.formatted(escapedPrompt);

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(API_URL))
            .timeout(Duration.ofSeconds(60))
            .header("Content-Type", "application/json")
            .header("x-goog-api-key", apiKey)
            .POST(HttpRequest.BodyPublishers.ofString(json))
            .build();

        HttpResponse<String> response = client.send(
            request,
            HttpResponse.BodyHandlers.ofString()
        );

        if (response.statusCode() != 200) {
            throw new RuntimeException(
                "Gemini API error: " + response.statusCode()
                + " - " + response.body()
            );
        }

        String body = response.body();

        int textPosition = body.indexOf("\"text\"");
        if (textPosition == -1) {
            throw new RuntimeException("No AI response received.");
        }

        int start = body.indexOf('"',
            body.indexOf(':', textPosition) + 1) + 1;

        StringBuilder result = new StringBuilder();
        boolean escaped = false;

        for (int i = start; i < body.length(); i++) {
            char c = body.charAt(i);

            if (escaped) {
                switch (c) {
                    case 'n' -> result.append('\n');
                    case 'r' -> result.append('\r');
                    case 't' -> result.append('\t');
                    default -> result.append(c);
                }
                escaped = false;
            } else if (c == '\\') {
                escaped = true;
            } else if (c == '"') {
                break;
            } else {
                result.append(c);
            }
        }

        return result.toString();
    }

    public String recommendFood(String preferences)
            throws Exception {

        return askAI(
            "Recommend the best food from our menu based on "
            + "these preferences: " + preferences
            + ". Explain why you recommend it."
        );
    }
}
