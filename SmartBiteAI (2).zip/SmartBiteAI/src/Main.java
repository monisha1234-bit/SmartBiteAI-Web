
    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println("       WELCOME TO SMARTBITE AI");
        System.out.println("================================");

        System.out.println("AI Based Food Ordering System");
        System.out.println("Order your favourite food!");

        System.out.println("Project Started Successfully!");
    }

public class Main {
    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println("       WELCOME TO SMARTBITE AI");
        System.out.println("================================");

        System.out.println("AI Based Food Ordering System");
        System.out.println("Order your favourite food!");

        System.out.println("Project Started Successfully!");
    }
}



