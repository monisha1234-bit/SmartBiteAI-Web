import javax.swing.*;
import java.awt.*;

public class SmartBiteApp {
static java.util.Map<String, Integer> cart =
    new java.util.LinkedHashMap<>();
    public static void main(String[] args) {
        SwingUtilities.invokeLater(SmartBiteApp::createUI);
    }

    private static void createUI() {
        JFrame frame = new JFrame("SmartBite AI");
        frame.setSize(700, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JLabel title = new JLabel("WELCOME TO SMARTBITE AI");
        title.setFont(new Font("Arial", Font.BOLD, 25));
        title.setForeground(new Color(230, 100, 20));

        JLabel subtitle = new JLabel(
            "Your Smart Food Ordering Assistant",
            SwingConstants.CENTER
        );

        JTextArea output = new JTextArea();
        output.setEditable(false);
        output.setLineWrap(true);
        output.setWrapStyleWord(true);
        output.setFont(new Font("Arial", Font.PLAIN, 15));

        JTextField input = new JTextField();
        input.setFont(new Font("Arial", Font.PLAIN, 15));

        JButton chatButton = new JButton("Chat with AI");
        JButton recommendButton =
            new JButton("AI Food Recommendations");

        GeminiService ai = new GeminiService();

        chatButton.addActionListener(e ->
            getAIResponse(ai, input, output, false,
                chatButton, recommendButton)
        );

        recommendButton.addActionListener(e ->
            getAIResponse(ai, input, output, true,
                chatButton, recommendButton)
        );

        JPanel top = new JPanel(new GridLayout(2, 1));
        top.add(title);
        top.add(subtitle);
        JPanel menuPanel = new JPanel(new GridLayout(4, 1, 5, 5));

JButton burger = new JButton("Burger - Rs.120");
JButton pizza = new JButton("Pizza - Rs.250");
JButton biryani = new JButton("Biryani - Rs.180");
JButton sandwich = new JButton("Sandwich - Rs.90");

burger.addActionListener(e -> cart.merge("Burger", 1, Integer::sum));
pizza.addActionListener(e -> cart.merge("Pizza", 1, Integer::sum));
biryani.addActionListener(e -> cart.merge("Biryani", 1, Integer::sum));
sandwich.addActionListener(e -> cart.merge("Sandwich", 1, Integer::sum));

menuPanel.add(burger);
menuPanel.add(pizza);
menuPanel.add(biryani);
menuPanel.add(sandwich);

        JPanel bottom = new JPanel(new BorderLayout(8, 8));
        JPanel buttons = new JPanel();
        JButton viewCartButton = new JButton("View Cart");
        JButton removeButton =new JButton("Remove from Cart");
        buttons.add(removeButton);
        removeButton.addActionListener(e -> {
    String item = JOptionPane.showInputDialog(
        frame, "Enter item name to remove:"
    );

    if (item != null && cart.containsKey(item)) {
        cart.remove(item);
        JOptionPane.showMessageDialog(frame, item + " removed from cart!");
    } else {
        JOptionPane.showMessageDialog(frame, "Item not found in cart!");
    }
});

    
buttons.add(viewCartButton);
viewCartButton.addActionListener(e -> {
    StringBuilder cartDetails = new StringBuilder("YOUR CART\n\n");
    int total = 0;

    for (String item : cart.keySet()) {
        int quantity = cart.get(item);
        int price = switch (item) {
            case "Burger" -> 120;
            case "Pizza" -> 250;
            case "Biryani" -> 180;
            case "Sandwich" -> 90;
            default -> 0;
        };

        cartDetails.append(item)
            .append(" x ").append(quantity)
            .append(" = Rs.").append(price * quantity)
            .append("\n");

        total += price * quantity;
    }

    cartDetails.append("\nTotal: Rs.").append(total);

    JOptionPane.showMessageDialog(frame, cartDetails.toString());
});
        buttons.add(chatButton);
        buttons.add(recommendButton);

        bottom.add(input, BorderLayout.CENTER);
        bottom.add(buttons, BorderLayout.SOUTH);

        frame.setLayout(new BorderLayout(10, 10));
        frame.add(top, BorderLayout.NORTH);
        frame.add(menuPanel,BorderLayout.WEST);
        frame.add(new JScrollPane(output), BorderLayout.CENTER);
        frame.add(bottom, BorderLayout.SOUTH);

        frame.setVisible(true);
    }

    private static void getAIResponse(
        GeminiService ai,
        JTextField input,
        JTextArea output,
        boolean recommendation,
        JButton chatButton,
        JButton recommendButton
    ) {
        String message = input.getText().trim();

        if (message.isEmpty()) {
            JOptionPane.showMessageDialog(
                null, "Please enter your message first."
            );
            return;
        }

        output.append("\nYou: " + message + "\n");
        output.append("SmartBite AI is thinking...\n");
        input.setText("");

        chatButton.setEnabled(false);
        recommendButton.setEnabled(false);

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                if (recommendation) {
                    return ai.recommendFood(message);
                }
                return ai.askAI(message);
            }

            @Override
            protected void done() {
                try {
                    output.append("SmartBite AI: " + get() + "\n");
                } catch (Exception ex) {
                    output.append(
                        "AI Error: " + ex.getMessage() + "\n"
                    );
                }

                chatButton.setEnabled(true);
                recommendButton.setEnabled(true);
            }
        }.execute();
    }
}